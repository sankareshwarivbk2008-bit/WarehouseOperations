# Warehouse Picking, Packing & Shipping

## Problem statement
Design a Java console application to manage warehouse items, locations, inventory, pick lists, picking, packing, shipments, and carrier dispatch.

## Requirements covered
- Add items and warehouse locations.
- Adjust inventory with non-negative stock validation.
- Create pick lists only when sufficient stock exists.
- Record picking and reduce on-hand inventory.
- Create a pack only after at least one quantity has been picked.
- Ship only a completed pack and display the shipment manifest.
- Display an inventory snapshot after each menu operation.
- Show requested, picked, packed quantities and discrepancies.

## How to run in Eclipse
1. Create a Java project named `WarehouseOperations`.
2. Create packages `model`, `service`, `util`, `exception`, and `main` under `src`.
3. Create each `.java` file in the matching package using the source files in this project.
4. Run `main.WarehouseMain` as a Java Application.

## Suggested test
1. Add item: `I101`, `Keyboard`, `pcs`.
2. Add location: `A1`, `Shelf A1`.
3. Adjust inventory: item `I101`, location `A1`, quantity `10`.
4. Create pick list: `I101`, `A1`, quantity `6`.
5. Record pick: pick list ID `1`, quantity `4`.
6. Record pick again: pick list ID `1`, quantity `2`.
7. Create pack: pick list ID `1`.
8. Ship order: pack ID `1`, carrier `ABC Logistics`.
9. View Inventory Summary. The remaining stock should be 4.

## Student details
Name: SANKARESHWARI M
Roll Number: [Enter your roll number]
