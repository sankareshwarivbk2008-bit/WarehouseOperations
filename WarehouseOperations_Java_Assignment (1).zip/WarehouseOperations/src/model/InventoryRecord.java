package model;

public class InventoryRecord {
    private final Item item;
    private final Location location;
    private int quantity;

    public InventoryRecord(Item item, Location location, int quantity) {
        this.item = item;
        this.location = location;
        this.quantity = quantity;
    }

    public Item getItem() { return item; }
    public Location getLocation() { return location; }
    public int getQuantity() { return quantity; }

    public void addQuantity(int amount) {
        if (amount < 0 && quantity + amount < 0) {
            throw new IllegalArgumentException("Inventory cannot become negative.");
        }
        quantity += amount;
    }
}
