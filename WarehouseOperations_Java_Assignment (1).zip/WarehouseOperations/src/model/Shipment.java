package model;

public class Shipment {
    private final int shipmentId;
    private final int packId;
    private final String carrier;
    private boolean dispatched;

    public Shipment(int shipmentId, int packId, String carrier) {
        this.shipmentId = shipmentId;
        this.packId = packId;
        this.carrier = carrier;
        this.dispatched = false;
    }

    public int getShipmentId() { return shipmentId; }
    public int getPackId() { return packId; }
    public String getCarrier() { return carrier; }
    public boolean isDispatched() { return dispatched; }
    public void dispatch() { dispatched = true; }
}
