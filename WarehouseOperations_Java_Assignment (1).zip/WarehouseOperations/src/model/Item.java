package model;

public class Item {
    private final String itemId;
    private final String name;
    private final String unit;

    public Item(String itemId, String name, String unit) {
        this.itemId = itemId;
        this.name = name;
        this.unit = unit;
    }

    public String getItemId() { return itemId; }
    public String getName() { return name; }
    public String getUnit() { return unit; }

    @Override
    public String toString() {
        return itemId + " - " + name + " (" + unit + ")";
    }
}
