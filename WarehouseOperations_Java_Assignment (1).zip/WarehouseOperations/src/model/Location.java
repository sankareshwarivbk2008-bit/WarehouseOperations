package model;

public class Location {
    private final String locationId;
    private final String description;

    public Location(String locationId, String description) {
        this.locationId = locationId;
        this.description = description;
    }

    public String getLocationId() { return locationId; }
    public String getDescription() { return description; }

    @Override
    public String toString() {
        return locationId + " - " + description;
    }
}
