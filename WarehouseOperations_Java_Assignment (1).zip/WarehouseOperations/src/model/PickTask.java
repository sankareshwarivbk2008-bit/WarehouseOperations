package model;

public class PickTask {
    private final Item item;
    private final Location location;
    private final int requestedQuantity;
    private int pickedQuantity;

    public PickTask(Item item, Location location, int requestedQuantity) {
        this.item = item;
        this.location = location;
        this.requestedQuantity = requestedQuantity;
        this.pickedQuantity = 0;
    }

    public Item getItem() { return item; }
    public Location getLocation() { return location; }
    public int getRequestedQuantity() { return requestedQuantity; }
    public int getPickedQuantity() { return pickedQuantity; }
    public int getDiscrepancy() { return requestedQuantity - pickedQuantity; }

    public void recordPick(int quantity) {
        if (quantity < 0 || pickedQuantity + quantity > requestedQuantity) {
            throw new IllegalArgumentException("Picked quantity must be between 0 and the remaining requested quantity.");
        }
        pickedQuantity += quantity;
    }
}
