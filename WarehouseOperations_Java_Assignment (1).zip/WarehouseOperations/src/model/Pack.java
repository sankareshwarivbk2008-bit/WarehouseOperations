package model;

public class Pack {
    private final int packId;
    private final int pickListId;
    private final int packedQuantity;
    private final int discrepancy;

    public Pack(int packId, int pickListId, int packedQuantity, int discrepancy) {
        this.packId = packId;
        this.pickListId = pickListId;
        this.packedQuantity = packedQuantity;
        this.discrepancy = discrepancy;
    }

    public int getPackId() { return packId; }
    public int getPickListId() { return pickListId; }
    public int getPackedQuantity() { return packedQuantity; }
    public int getDiscrepancy() { return discrepancy; }
}
