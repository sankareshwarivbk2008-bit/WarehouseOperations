package model;

import java.util.ArrayList;
import java.util.List;

public class PickList {
    private final int pickListId;
    private final List<PickTask> tasks = new ArrayList<>();
    private boolean packed;

    public PickList(int pickListId) { this.pickListId = pickListId; }
    public int getPickListId() { return pickListId; }
    public List<PickTask> getTasks() { return tasks; }
    public boolean isPacked() { return packed; }
    public void addTask(PickTask task) { tasks.add(task); }
    public void markPacked() { packed = true; }
}
