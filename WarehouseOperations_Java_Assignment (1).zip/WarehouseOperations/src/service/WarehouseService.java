package service;

import java.util.*;
import model.*;
import exception.InsufficientInventoryException;

public class WarehouseService {
    private final Map<String, Item> items = new LinkedHashMap<>();
    private final Map<String, Location> locations = new LinkedHashMap<>();
    private final Map<String, InventoryRecord> inventory = new LinkedHashMap<>();
    private final Map<Integer, PickList> pickLists = new LinkedHashMap<>();
    private final Map<Integer, Pack> packs = new LinkedHashMap<>();
    private final Map<Integer, Shipment> shipments = new LinkedHashMap<>();
    private int nextPickListId = 1, nextPackId = 1, nextShipmentId = 1;

    private String key(String itemId, String locationId) {
        return itemId + "::" + locationId;
    }

    public void addItem(String id, String name, String unit) {
        if (items.containsKey(id)) throw new IllegalArgumentException("Item ID already exists.");
        items.put(id, new Item(id, name, unit));
    }

    public void addLocation(String id, String description) {
        if (locations.containsKey(id)) throw new IllegalArgumentException("Location ID already exists.");
        locations.put(id, new Location(id, description));
    }

    public void adjustInventory(String itemId, String locationId, int amount) {
        Item item = requireItem(itemId);
        Location location = requireLocation(locationId);
        if (amount == 0) throw new IllegalArgumentException("Quantity adjustment cannot be zero.");
        String k = key(itemId, locationId);
        InventoryRecord record = inventory.get(k);
        if (record == null) {
            if (amount < 0) throw new IllegalArgumentException("No inventory exists to reduce.");
            inventory.put(k, new InventoryRecord(item, location, amount));
        } else {
            record.addQuantity(amount);
        }
    }

    public PickList createPickList(String itemId, String locationId, int quantity)
            throws InsufficientInventoryException {
        if (quantity <= 0) throw new IllegalArgumentException("Quantity must be greater than zero.");
        Item item = requireItem(itemId);
        Location location = requireLocation(locationId);
        InventoryRecord record = inventory.get(key(itemId, locationId));
        int available = record == null ? 0 : record.getQuantity();
        if (available < quantity) {
            throw new InsufficientInventoryException("Insufficient stock. Available: " + available + ", requested: " + quantity);
        }
        PickList list = new PickList(nextPickListId++);
        list.addTask(new PickTask(item, location, quantity));
        pickLists.put(list.getPickListId(), list);
        return list;
    }

    public void recordPick(int pickListId, int quantity) {
        PickList list = requirePickList(pickListId);
        if (list.isPacked()) throw new IllegalArgumentException("This pick list has already been packed.");
        if (list.getTasks().size() != 1) throw new IllegalStateException("Unexpected pick task count.");
        PickTask task = list.getTasks().get(0);
        int remaining = task.getRequestedQuantity() - task.getPickedQuantity();
        if (quantity <= 0 || quantity > remaining) {
            throw new IllegalArgumentException("Enter a quantity from 1 to " + remaining + ".");
        }
        InventoryRecord record = inventory.get(key(task.getItem().getItemId(), task.getLocation().getLocationId()));
        if (record == null || record.getQuantity() < quantity) {
            throw new IllegalArgumentException("Not enough stock remains at the selected location.");
        }
        record.addQuantity(-quantity);
        task.recordPick(quantity);
    }

    public Pack createPack(int pickListId) {
        PickList list = requirePickList(pickListId);
        if (list.isPacked()) throw new IllegalArgumentException("This pick list has already been packed.");
        int totalRequested = 0, totalPicked = 0;
        for (PickTask task : list.getTasks()) {
            totalRequested += task.getRequestedQuantity();
            totalPicked += task.getPickedQuantity();
        }
        if (totalPicked == 0) throw new IllegalArgumentException("Record at least one picked item before packing.");
        Pack pack = new Pack(nextPackId++, pickListId, totalPicked, totalRequested - totalPicked);
        packs.put(pack.getPackId(), pack);
        list.markPacked();
        return pack;
    }

    public Shipment shipOrder(int packId, String carrier) {
        Pack pack = packs.get(packId);
        if (pack == null) throw new IllegalArgumentException("Pack ID not found. Create a pack first.");
        if (carrier.trim().isEmpty()) throw new IllegalArgumentException("Carrier name cannot be empty.");
        Shipment shipment = new Shipment(nextShipmentId++, packId, carrier);
        shipment.dispatch();
        shipments.put(shipment.getShipmentId(), shipment);
        return shipment;
    }

    public void showInventory() {
        System.out.println("\n--- INVENTORY SNAPSHOT ---");
        if (inventory.isEmpty()) System.out.println("No inventory records.");
        for (InventoryRecord r : inventory.values()) {
            System.out.printf("%s | %s | Quantity: %d%n",
                    r.getItem().getItemId() + " - " + r.getItem().getName(),
                    r.getLocation().getLocationId() + " - " + r.getLocation().getDescription(),
                    r.getQuantity());
        }
        System.out.println("--------------------------");
    }

    public void showPickSummary(int id) {
        PickList list = requirePickList(id);
        System.out.println("\n--- PICK SUMMARY: " + id + " ---");
        for (PickTask t : list.getTasks()) {
            System.out.println("Item: " + t.getItem().getName() + " | Location: " + t.getLocation().getLocationId()
                    + " | Requested: " + t.getRequestedQuantity() + " | Picked: " + t.getPickedQuantity()
                    + " | Discrepancy: " + t.getDiscrepancy());
        }
    }

    public void showManifest(int shipmentId) {
        Shipment s = shipments.get(shipmentId);
        if (s == null) throw new IllegalArgumentException("Shipment ID not found.");
        Pack p = packs.get(s.getPackId());
        PickList pl = requirePickList(p.getPickListId());
        System.out.println("\n--- SHIPMENT MANIFEST ---");
        System.out.println("Shipment ID: " + s.getShipmentId());
        System.out.println("Carrier: " + s.getCarrier());
        System.out.println("Status: " + (s.isDispatched() ? "DISPATCHED" : "OPEN"));
        System.out.println("Pack ID: " + p.getPackId());
        for (PickTask t : pl.getTasks()) {
            System.out.println(t.getItem().getName() + " | Quantity shipped: " + t.getPickedQuantity());
        }
        System.out.println("Total quantity: " + p.getPackedQuantity());
        System.out.println("-------------------------");
    }

    public Set<String> getItemIds() { return items.keySet(); }
    public Set<String> getLocationIds() { return locations.keySet(); }
    public Set<Integer> getPickListIds() { return pickLists.keySet(); }
    public Set<Integer> getPackIds() { return packs.keySet(); }
    public Set<Integer> getShipmentIds() { return shipments.keySet(); }

    private Item requireItem(String id) {
        Item item = items.get(id);
        if (item == null) throw new IllegalArgumentException("Item ID not found.");
        return item;
    }
    private Location requireLocation(String id) {
        Location location = locations.get(id);
        if (location == null) throw new IllegalArgumentException("Location ID not found.");
        return location;
    }
    private PickList requirePickList(int id) {
        PickList list = pickLists.get(id);
        if (list == null) throw new IllegalArgumentException("Pick list ID not found.");
        return list;
    }
}
