package main;

import service.WarehouseService;
import util.InputUtil;
import model.PickList;
import model.Pack;
import model.Shipment;
import exception.InsufficientInventoryException;

public class WarehouseMain {
    public static void main(String[] args) {
        WarehouseService service = new WarehouseService();
        InputUtil in = new InputUtil();
        boolean running = true;

        while (running) {
            System.out.println("\n===== WAREHOUSE OPERATIONS =====");
            System.out.println("1. Add Item");
            System.out.println("2. Add Location");
            System.out.println("3. Adjust Inventory");
            System.out.println("4. Create Pick List");
            System.out.println("5. Record Pick");
            System.out.println("6. Create Pack");
            System.out.println("7. Ship Order");
            System.out.println("8. Inventory Summary");
            System.out.println("9. Exit");

            int choice = in.readInt("Enter choice: ");
            try {
                switch (choice) {
                    case 1:
                        service.addItem(in.readText("Item ID: "), in.readText("Item name: "),
                                in.readText("Unit (e.g. pcs): "));
                        System.out.println("Item added successfully.");
                        break;
                    case 2:
                        service.addLocation(in.readText("Location ID: "), in.readText("Location description: "));
                        System.out.println("Location added successfully.");
                        break;
                    case 3:
                        service.adjustInventory(in.readText("Item ID: "), in.readText("Location ID: "),
                                in.readInt("Quantity adjustment (+ to add, - to reduce): "));
                        System.out.println("Inventory adjusted successfully.");
                        break;
                    case 4: {
                        PickList p = service.createPickList(in.readText("Item ID: "), in.readText("Location ID: "),
                                in.readInt("Quantity to pick: "));
                        System.out.println("Pick list created. Pick List ID: " + p.getPickListId());
                        break;
                    }
                    case 5: {
                        int id = in.readInt("Pick List ID: ");
                        int qty = in.readInt("Quantity picked now: ");
                        service.recordPick(id, qty);
                        System.out.println("Pick recorded successfully.");
                        service.showPickSummary(id);
                        break;
                    }
                    case 6: {
                        Pack p = service.createPack(in.readInt("Pick List ID: "));
                        System.out.println("Pack created. Pack ID: " + p.getPackId());
                        System.out.println("Packed quantity: " + p.getPackedQuantity()
                                + " | Discrepancy: " + p.getDiscrepancy());
                        break;
                    }
                    case 7: {
                        Shipment s = service.shipOrder(in.readInt("Pack ID: "), in.readText("Carrier name: "));
                        System.out.println("Shipment dispatched. Shipment ID: " + s.getShipmentId());
                        service.showManifest(s.getShipmentId());
                        break;
                    }
                    case 8:
                        service.showInventory();
                        break;
                    case 9:
                        running = false;
                        System.out.println("Exiting Warehouse Operations. Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid menu option. Choose 1-9.");
                }
            } catch (InsufficientInventoryException e) {
                System.out.println("VALIDATION ERROR: " + e.getMessage());
            } catch (IllegalArgumentException | IllegalStateException e) {
                System.out.println("ERROR: " + e.getMessage());
            } finally {
                service.showInventory();
            }
        }
    }
}
